package org.sid.walletservice.enums;

public enum WalletTransactionType {
    DEBIT, CREDIT
}
